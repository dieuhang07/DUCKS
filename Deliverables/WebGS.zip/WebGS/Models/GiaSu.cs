﻿namespace WebGS.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("GiaSu")]
    public partial class GiaSu
    {
        public int ID { get; set; }
        [Display(Name ="Tên")]
        [StringLength(250)]
        public string Ten { get; set; }
        [Display(Name = "Giới tính")]
        public int? Gioitinh { get; set; }
        [Display(Name = "Ngày sinh")]
        [StringLength(250)]
        public string Ngaysinh { get; set; }
        [Display(Name = "Số chứng minh thư")]
        [StringLength(250)]
        public string CMND { get; set; }
        [Display(Name = "Quê Quán")]
        [StringLength(250)]
        public string QueQuan { get; set; }
        [Display(Name = "Địa chỉ")]
        [StringLength(250)]
        public string DiaChi { get; set; }
        [Display(Name = "Email")]
        [StringLength(250)]
        public string Email { get; set; }
        [Display(Name = "Số điện thoại")]
        [StringLength(250)]
        public string SDT { get; set; }
        [Display(Name = "Ảnh chứng minh thư mặt trước")]
        [StringLength(250)]
        public string AnhCMNDtruoc { get; set; }
        [Display(Name = "Ảnh chứng minh thư mặt sau")]
        [StringLength(250)]
        public string AnhCMNDsau { get; set; }
        [Display(Name = "Ảnh thẻ")]
        [StringLength(250)]
        public string AnhThe { get; set; }
        [Display(Name = "Bằng cấp")]
        [StringLength(250)]
        public string BangCap { get; set; }
        [Display(Name = "Trường học")]
        [StringLength(250)]
        public string TruongHoc { get; set; }
        [Display(Name = "Chuyên nghành")]
        [StringLength(250)]
        public string Nganh { get; set; }
        [Display(Name = "Năm tốt nghiệp")]
        [StringLength(250)]
        public string Namtotnghiep { get; set; }
        [Display(Name = "Ưu điểm")]
        [StringLength(250)]
        public string Uudien { get; set; }
        [Display(Name = "Môn Dạy")]
        [StringLength(250)]
        public string MonDay { get; set; }
        [Display(Name = "Khu vực")]
        [StringLength(250)]
        public string Khuvuc { get; set; }
        [Display(Name = "Thời gian")]
        [StringLength(250)]
        public string Thoigianday { get; set; }
        [Display(Name = "Mức lương")]
        [StringLength(250)]
        public string Mucluong { get; set; }
        [Display(Name = "Khác")]
        [StringLength(250)]
        public string khac { get; set; }
        [Display(Name = "Cho phép hiển thị")]
        public bool? Isshow { get; set; }
    }
}
