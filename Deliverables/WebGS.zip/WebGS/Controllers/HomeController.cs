﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebGS.Models;

namespace WebGS.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string UserName, string Password)
        {
            using (var db = new Model1())
            {
                var user = db.Users.SingleOrDefault(x => x.UserName == UserName && x.Password == Password);
                if (user != null)
                {
                    Session["User"] = user;
                    return RedirectToAction("/");
                }
                else
                {
                    ViewBag.error = "Thông tin không chính xác vui lòng nhập lại";
                }
            }
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(User user)
        {
            using (var db = new Model1())
            {
                if (ModelState.IsValid)
                {
                    user.Role = 2;
                    db.Users.Add(user);
                    db.SaveChanges();
                    Session["User"] = user;
                    return RedirectToAction("/");
                }

                return View(user);
            }
        }
        public ActionResult Courses()
        {
            using (var db = new Model1())
            {
                var Gs = db.GiaSus.Where(x=>x.Isshow == true).ToList();
                return View(Gs);
            }
        }
        public ActionResult Detail()
        {
            return View();
        }
        public ActionResult admin()
        {
            return View();
        }
        public ActionResult AddGS()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddGS(GiaSu giaSu, HttpPostedFileBase CMNDtruoc, HttpPostedFileBase CMNDsau, HttpPostedFileBase Anhthe)
        {
            if (ModelState.IsValid)
            {
                if (CMNDtruoc != null)
                {
                    string pic = System.IO.Path.GetFileName(CMNDtruoc.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    CMNDtruoc.SaveAs(path);
                    giaSu.AnhCMNDtruoc = "/Content/Img/" + CMNDtruoc.FileName;
                }
                else
                {
                    giaSu.AnhCMNDtruoc = null;
                }
                if (CMNDsau != null)
                {
                    string pic = System.IO.Path.GetFileName(CMNDsau.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    CMNDsau.SaveAs(path);
                    giaSu.AnhCMNDsau = "/Content/Img/" + CMNDsau.FileName;
                }
                else
                {
                    giaSu.AnhCMNDsau = null;
                }
                if (Anhthe != null)
                {
                    string pic = System.IO.Path.GetFileName(Anhthe.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    Anhthe.SaveAs(path);
                    giaSu.AnhThe = "/Content/Img/" + Anhthe.FileName;
                }
                else
                {
                    giaSu.AnhThe = null;
                }
                //--------------------
            }
            using (var db = new Model1())
            {
                giaSu.Isshow = false;
                db.GiaSus.Add(giaSu);
                db.SaveChanges();
            }
            return View(giaSu);
        }
        public ActionResult Logout()
        {
            Session.Remove("user");
            return RedirectToAction("/");
        }
    }
}