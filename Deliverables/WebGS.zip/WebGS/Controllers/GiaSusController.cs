﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebGS.Models;

namespace WebGS.Controllers
{
    public class GiaSusController : Controller
    {
        private Model1 db = new Model1();

        // GET: GiaSus
        public ActionResult Index()
        {
            return View(db.GiaSus.ToList());
        }

        // GET: GiaSus/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GiaSu giaSu = db.GiaSus.Find(id);
            if (giaSu == null)
            {
                return HttpNotFound();
            }
            return View(giaSu);
        }

        // GET: GiaSus/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: GiaSus/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(GiaSu giaSu, HttpPostedFileBase CMNDtruoc, HttpPostedFileBase CMNDsau, HttpPostedFileBase Anhthe)
        {
            if (ModelState.IsValid)
            {
                if (CMNDtruoc != null)
                {
                    string pic = System.IO.Path.GetFileName(CMNDtruoc.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    CMNDtruoc.SaveAs(path);
                    giaSu.AnhCMNDtruoc = "/Content/Img/"+ CMNDtruoc.FileName;
                }
                else
                {
                    giaSu.AnhCMNDtruoc = null;
                }
                if (CMNDsau != null)
                {
                    string pic = System.IO.Path.GetFileName(CMNDsau.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    CMNDsau.SaveAs(path);
                    giaSu.AnhCMNDtruoc = "/Content/Img/" + CMNDsau.FileName;
                }
                else
                {
                    giaSu.AnhCMNDsau = null;
                }
                if (Anhthe != null)
                {
                    string pic = System.IO.Path.GetFileName(Anhthe.FileName);
                    string path = System.IO.Path.Combine(
                                           Server.MapPath("/Content/Img"), pic);
                    // file is uploaded
                    Anhthe.SaveAs(path);
                    giaSu.AnhCMNDtruoc = "/Content/Img/" + Anhthe.FileName;
                }
                else
                {
                    giaSu.AnhThe = null;
                }
                //--------------------
            }
            db.GiaSus.Add(giaSu);
            db.SaveChanges();
            return View(giaSu);
        }

        // GET: GiaSus/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GiaSu giaSu = db.GiaSus.Find(id);
            if (giaSu == null)
            {
                return HttpNotFound();
            }
            return View(giaSu);
        }

        // POST: GiaSus/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Ten,Gioitinh,Ngaysinh,CMND,QueQuan,DiaChi,Email,SDT,AnhCMNDtruoc,AnhCMNDsau,AnhThe,BangCap,TruongHoc,Nganh,Namtotnghiep,Uudien,MonDay,Khuvuc,Thoigianday,Mucluong,khac,Isshow")] GiaSu giaSu)
        {
            if (ModelState.IsValid)
            {
                giaSu.Isshow = true;
                db.Entry(giaSu).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(giaSu);
        }

        // GET: GiaSus/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GiaSu giaSu = db.GiaSus.Find(id);
            if (giaSu == null)
            {
                return HttpNotFound();
            }
            return View(giaSu);
        }

        // POST: GiaSus/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            GiaSu giaSu = db.GiaSus.Find(id);
            db.GiaSus.Remove(giaSu);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
